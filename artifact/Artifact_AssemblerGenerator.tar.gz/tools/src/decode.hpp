#ifndef DECODE_PARSE_HPP
#define DECODE_PARSE_HPP

#include "decode_common.hpp"
 
/**
 * @file decode.hpp
 * Defines functions and constants used by the parser.
 */

#define NUM_MOD_TYPES 11
#define MOD_FLAG 0
#define MOD_TYPE 1
#define MOD_PROPOSITION 2
#define MOD_COMPARE 3
#define MOD_ROUND 4
#define MOD_SHIFTDIRECTION 5
#define MOD_INVALIDCHKMODE 6
#define MOD_IADD3 7
#define MOD_MUFU 8
#define MOD_XMAD 9
#define MOD_IMNMX 10

typedef struct {
	char * token;
	bool vals[64];
	bool matters[64];
	bool antivals[64];//vals when mod is *not* present (currently only used for flag type mods)
	bool seenAntiVal;//true if antivals has been properly set
	
	int type;//0 for generic, 1 for data-type, 2 for and/or/xor
	int count;//0 for generic or 1st non-generic of its own type, 1 for second non-generic of its own type
	
	bool combine;//false iff we should avoid combining this with same mod from other versions of same operation
} operationMod;

typedef struct {
	token_type type;
	bool possibleStart1[64];
	int maxBits1[64];
	bool possibleStart2[64];
	int maxBits2[64];
	bool possibleStart3[64];
	int maxBits3[64];
	int components;
	node * mods;
	
	operand_prop properties;//has a 1 bit (only) for each observed property
	bool propMatters[4][64];
	bool propVals[4][64];
	
	bool decimal;//true iff a float/double literal
	bool relative;//true iff must be a relative address (hex operands only)
	bool incNegative;//true iff negative prop is applied to hex operand instead of flipping a bit
	bool addlNegative;//true if hex operand needs to be multiplied by -1 (e.g. last operand in ISUB)
	bool shiftComp3;//indicates whether val3 needs to be bit shifted (for constant memory)
} operationOperand;

typedef struct {
	int op;//enum id from common.hpp
	bool confirmedGuard;
	bool binid[64];//actual opcode
	bool binidmatters[64];//indicates which bits might matter for opcode
	operationOperand * operands[8];
	int numOperands;
	node * mods;
	int noModBits[NUM_MOD_TYPES][64];
} operation;

/**
 * Returns the kind of mod a mod string corresponds to.
 * @param modstr The mod string
 * @return an int
 */
int getModType(const char * modstr);

///TODO: comments
int getOpcode(const char * opname);

///TODO comments
void analyze(instruction * inst, char * hexstring);

#endif

