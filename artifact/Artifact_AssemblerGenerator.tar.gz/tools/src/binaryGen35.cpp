//Placeholder for newly generated assembler code
bool binary[64];
