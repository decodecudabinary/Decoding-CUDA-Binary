#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "binary.hpp"
#include "common.hpp"
using namespace std;

char* instructionToHexStringGen35(instruction * inst, int cuobjdump_version) {
	//Import generated Compute Capability 3.5 assembler:
	#include "binaryGen35.cpp"
	
	 if(inst->op == opcode_BINCODE) {
		char * binstr = (char*) inst->mods->value;
		for(int x = 0; x < 64; x++) {
			binary[x] = (binstr[x] == '1');
		}
	}
	
	//Convert binary to correct format:
	char * answer = (char*) malloc(17);
	answer[16] = 0;
	for(int x = 0; x < 64; x+=4) {
		int blah = 0;
		if(binary[60-x]) {
			blah++;
		}
		if(binary[61-x]) {
			blah+=2;
		}
		if(binary[62-x]) {
			blah+=4;
		}
		if(binary[63-x]) {
			blah+=8;
		}
		if(blah < 10) {
			int y = x + 32;
			if(x >= 32) {
				y = x - 32;
			}
			answer[y/4] = blah + '0';
		} else {
			int y = x + 32;
			if(x >= 32) {
				y = x - 32;
			}
			answer[y/4] = blah + 'a' - 10;
		}
	}
	return answer;
}
