#ifndef CUDACOMMON_HPP
#define CUDACOMMON_HPP
#include "common.hpp"

/**
 * @file cudacommon.hpp
 * Defines functions used to analyze CUDA code.
 */

/**
 * Checks if instruction has given mod attached to opcode.
 * @param inst The instruction
 * @param mod The mod string
 * @return true iff mod is present, false iff not
 */
bool hasMod(instruction* inst, const char* mod);

/**
 * Checks if operand has given mod.
 * @param op The operand
 * @param mod The mod string
 * @return true iff mod is present, false iff not
 */
bool hasMod(operand* op, const char* mod);

/**
 * Checks if instruction has given mod in appropriate place, associated with the opcode.
 * @param inst The instruction
 * @param mod The mod string
 * @param later Should be 1 iff target mod is after a type mod; 0 if before
 * @return true iff mod is present, false iff not
 */
bool hasTypeMod(instruction* inst, const char* mod, char later);

/**
 * Returns the number of cycles represented by a dispatch interval.
 * @oaram arch The architecture for the assembly (e.g. 20 for Fermi, 30 or 35 for Kepler).
 * @param schi The dispatch value.
 * @return The number of cycles before the next instruction can be dispatched.
 */
int schiToCycles(int arch, int schi);

/**
 * Gets the basic block which contains the given line.
 * @param line The line number for an instruction
 * @return the blockNode which contains the line, or 0 if no such line exists
 */
blockNode * getBlock(int line);

/**
 * Gets the basic block which contains the given instruction.
 * @param inst The instruction
 * @return the blockNode which contains the instruction, or 0 if no such line exists
 */
blockNode * getBlock(instruction * inst);

/**
 * Gets the instruction with the given line number.
 * @param line The line number for an instruction
 * @return the desired instruction
 */
instruction * getLine(int line);

#endif
