The tools subdirectory contains our assembler generator.
The benchmarks subdirectory contains sample inputs for the assembler generator.
See each subdirectory's readme.txt files for more information.
